CrystalView - upload this project to GitHub and run the provided GitHub Actions workflow to build the APK.
Package: com.crystalview.app
